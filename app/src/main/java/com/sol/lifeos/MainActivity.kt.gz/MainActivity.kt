package com.sol.lifeos

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.tween
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.EventNote
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.LocalLaundryService
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

private val Bg = Color(0xFF002A32)
private val Panel = Color(0xFF073740)
private val PanelAlt = Color(0xFF03242B)
private val Line = Color(0xFF24515A)
private val Ink = Color(0xFFF1F7F5)
private val Muted = Color(0xFFA8BEC0)
private val Blue = Color(0xFF8AD0CB)
private val Gold = Color(0xFFF0D39A)
private val Green = Color(0xFF83D8B6)
private val Red = Color(0xFFED254E)
private val CoralSoft = Color(0xFF401E2B)

private data class Mission(val id: String, val label: String, val xp: Int, val category: String = "general", val note: String = "")
private data class MissionGroup(val title: String, val tasks: List<Mission>)
private data class MissionEntry(val id: String, val label: String, val xp: Int, val category: String)
private data class Achievement(val id: String, val icon: String, val title: String, val description: String)
private data class Reward(val id: String, val icon: String, val name: String, val description: String, val cost: Int)
private data class WeekStats(val start: LocalDate, val end: LocalDate, val tasks: Int, val xp: Int, val days: Int)
private data class TimerSnapshot(val endAt: Long, val durationSeconds: Int, val label: String, val running: Boolean)
private data class TimerSession(val label: String, val minutes: Int, val date: Long)

private val SleepTimes = listOf("00:30", "00:15", "00:00", "23:45", "23:30")
private val Achievements = listOf(
    Achievement("first", "🌱", "Primeiro passo", "Conclua sua primeira missão."),
    Achievement("ten", "🧭", "A campanha começou", "Conclua 10 missões no total."),
    Achievement("xp100", "⚡", "Em evolução", "Acumule 100 XP."),
    Achievement("ritual", "🏆", "Chefe derrotado", "Conclua água, comida e banho no ritual."),
    Achievement("active3", "📆", "Voltando sempre", "Tenha missões concluídas em 3 dias diferentes."),
    Achievement("active7", "🔥", "Ritmo construído", "Tenha missões concluídas em 7 dias diferentes."),
    Achievement("study", "📚", "Conhecimento desbloqueado", "Conclua uma sessão de estudo."),
    Achievement("fitness", "🏋️", "Corpo em movimento", "Conclua um treino de calistenia."),
    Achievement("survival", "🩵", "Proteger o jogador", "Conclua todas as missões de um modo de sobrevivência.")
)

private object Missions {
    val ritual1 = listOf(
        Mission("arrived", "Cheguei em casa.", 0, "health"),
        Mission("water", "Bebi água.", 5, "health"),
        Mission("food", "Comi alguma coisa: lanche ou jantar.", 10, "health")
    )
    val ritual2 = listOf(
        Mission("bath", "Tomei meu banho morno.", 10, "health"),
        Mission("change", "Troquei de roupa.", 5, "health"),
        Mission("ready", "Estou pronto para descansar.", 5, "health")
    )
    val ritual3 = listOf(Mission("pc", "PC liberado! Posso jogar, assistir ou simplesmente não fazer nada.", 5, "rest"))
    val survivalBad = listOf(
        Mission("sv_water", "Beber água e comer alguma coisa.", 5, "health"),
        Mission("sv_bath", "Tomar banho. Se não der, lavar o rosto e trocar de roupa.", 5, "health"),
        Mission("sv_item", "Pegar apenas 1 item do chão e colocá-lo no lugar.", 5, "home"),
        Mission("sv_teeth", "Escovar os dentes e colocar o celular para carregar.", 5, "health")
    )
    val survivalWorst = listOf(
        Mission("sw_food", "Comer alguma coisa.", 5, "health"),
        Mission("sw_teeth", "Escovar os dentes.", 5, "health")
    )
    val laundry = listOf(
        listOf("Pegar o lixo do chão e jogar fora", "Levar copos e pratos para a cozinha", "Esticar a cama (2 min)", "Tirar roupas da cadeira: sujas no cesto, limpas em uma pilha", "Levar o cesto de roupa suja do outro quarto para o seu", "Descobrir qual sabão e amaciante são usados e onde ficam", "Guardar a pilha de roupas limpas em uma gaveta ou cabide"),
        listOf("Tirar o pó da mesa e do PC", "Varrer o quarto por 5 min", "Tirar as roupas de cima da cama e esticá-la", "Pendurar 5 roupas no guarda-roupa", "Dia livre", "Observar alguém lavando roupa: separar, dosar, ligar e pendurar", "Separar uma gaveta para roupas de uso diário"),
        listOf("Manter o chão livre e 1 minuto para o lixo", "1 minuto para a cama", "Dobrar 5 peças de roupa por dia", "Separar camisetas e cuecas", "Colocar a quantidade adequada de sabão", "Adicionar amaciante e escolher o ciclo", "Acompanhar a lavagem e pendurar as peças no varal", "Guardar tudo"),
        listOf("Manutenção de 10 min: chão, cama e uma superfície", "Separar a roupa", "Preparar a máquina e dosar os produtos", "Escolher o ciclo", "Lavar uma carga completa sozinho", "Pedir ao irmão para ensinar a lavar a farda branca", "Guardar as roupas e planejar a próxima semana")
    )
    val laundryRewards = listOf("Chão livre desbloqueado", "Organização básica desbloqueada", "Primeira lavagem concluída", "MESTRE DO CICLO DE LAVAGEM")
    val laundryTitles = listOf("NÍVEL 1 — O SOBREVIVENTE DO LIXO", "NÍVEL 2 — O DOMADOR DE SUPERFÍCIES", "NÍVEL 3 — O APRENDIZ DA MÁQUINA", "NÍVEL 4 — O MESTRE DO CICLO DE LAVAGEM")
    val laundrySubs = listOf("Semana 1 · Desbloqueio do ambiente", "Semana 2 · Organização básica", "Semana 3 · Primeira lavagem", "Semana 4 · Autonomia")
    val fitnessTitles = listOf("NÍVEL 1 — INICIANTE", "NÍVEL 2 — CONTROLE", "NÍVEL 3 — RESISTÊNCIA", "NÍVEL 4 — AUTONOMIA")
    val fitnessDescriptions = listOf(
        "Aprender os exercícios; realizar 2 rodadas; priorizar postura e controle; usar versões facilitadas.",
        "Continuar com 2 rodadas; melhorar a execução; controlar os movimentos sem pressa; reconhecer os limites.",
        "Passar para 3 rodadas; manter os exercícios; sustentar a execução sem sacrificar a postura.",
        "Realizar 3 rodadas; conhecer a sequência; executar com confiança; saber quando interromper por dor."
    )
    val exercises = listOf(
        "Aquecimento · 3 min" to "Mobilidade + 20 polichinelos + 10 agachamentos",
        "Core" to "Prancha de antebraços", "Coordenação" to "Dead bug", "Quadril" to "Ponte de glúteos",
        "Abdômen" to "Bicicleta no chão", "Abdômen inferior" to "Elevação de pernas deitado",
        "Estabilidade" to "Bird dog", "Volta à calma · 2 min" to "Alongamento cobra + posição da criança"
    )

    fun schedule(date: LocalDate): List<MissionGroup> {
        val mondayStudy = date.dayOfWeek.value % 2 == 1
        if (date.dayOfWeek.value in 1..4) {
            val groups = mutableListOf(
                MissionGroup("MANHÃ · 05:10", listOf(Mission("light", "Acordar, beber água e acender a luz forte do quarto", 5, "health", "Essencial"))),
                MissionGroup("ÔNIBUS DE IDA", listOf(Mission("flash", "Áudio ou 5 min de flashcards de CNH/japonês (opcional)", 5, "study", "Opcional"))),
                MissionGroup("ÔNIBUS DE VOLTA", listOf(Mission("nap", "Cochilo de 15–25 min com alarme", 5, "health", "Essencial"))),
                MissionGroup("CHEGADA · ~18:10", listOf(Mission("water", "Beber água antes do PC", 5, "health", "Essencial"), Mission("food", "Comer alguma coisa antes do PC", 10, "health", "Essencial"))),
                MissionGroup("REGENERAÇÃO · ~18:30", listOf(Mission("bath", "Banho morno", 10, "health", "Essencial"))),
                MissionGroup("RECUPERAÇÃO", listOf(Mission("rest", "Descanso livre", 5, "rest", "Opcional"))),
                MissionGroup("19:40 · CASA", listOf(Mission("home", "Micro-hábito doméstico de 10–15 min", 10, "home", "Opcional")))
            )
            groups += if (mondayStudy) MissionGroup("20:00 · Estudo", listOf(Mission("study", "Estudar por 20–25 min", 15, "study", "Opcional"))) else MissionGroup("20:00 · Treino", listOf(Mission("workout", "Calistenia por 20 min", 20, "fitness", "Opcional")))
            groups += listOf(
                MissionGroup("NOITE", listOf(Mission("shirt", "Tempo livre e separar a farda (opcional)", 5, "health", "Opcional"))),
                MissionGroup("~21:00 · TEMPO PESSOAL", listOf(Mission("call", "Ligação com sua namorada (opcional)", 5, "relationship", "Opcional"))),
                MissionGroup("23:00 · DESACELERAÇÃO", listOf(Mission("teeth", "Escovar os dentes, reduzir luz e carregar celular longe da cama", 10, "health", "Essencial"))),
                MissionGroup("00:30 · SONO", listOf(Mission("bed", "Deitar no horário-alvo inicial", 5, "health", "Essencial")))
            )
            return groups
        }
        if (date.dayOfWeek == DayOfWeek.FRIDAY) return listOf(
            MissionGroup("CHEGADA · ~17:10", listOf(Mission("water", "Beber água antes do PC", 5, "health", "Essencial"), Mission("food", "Comer alguma coisa antes do PC", 10, "health", "Essencial"))),
            MissionGroup("DEPOIS DE COMER", listOf(Mission("bath", "Banho", 10, "health", "Essencial"))),
            MissionGroup("Quando puder", listOf(Mission("basket", "Levar o cesto de roupa suja para perto da máquina", 5, "home", "Opcional"))),
            MissionGroup("RESTANTE DA NOITE", listOf(Mission("rest", "Lazer livre, sem tarefas adicionais", 5, "rest", "Opcional"))),
            MissionGroup("23:00 · DESACELERAÇÃO", listOf(Mission("teeth", "Desaceleração e higiene", 10, "health", "Essencial"))),
            MissionGroup("00:30 · SONO", listOf(Mission("bed", "Deitar no horário-alvo", 5, "health", "Essencial")))
        )
        if (date.dayOfWeek == DayOfWeek.SATURDAY) return listOf(
            MissionGroup("ATÉ 08:00", listOf(Mission("light", "Acordar, água e café", 5, "health", "Essencial"))),
            MissionGroup("09:00 · AMBIENTE", listOf(Mission("room", "Mini-arrumação do quarto por 15–20 min com música", 10, "home", "Opcional"))),
            MissionGroup("10:00 · TREINO", listOf(Mission("workout", "Calistenia por 20 min", 20, "fitness", "Opcional"))),
            MissionGroup("10:30 · BANHO", listOf(Mission("bath", "Banho", 10, "health", "Essencial"))),
            MissionGroup("11:00 · LAVANDERIA (A PARTIR DA SEMANA 3)", listOf(Mission("laundry", "Lavar roupa", 25, "home", "Opcional"))),
            MissionGroup("12:00–17:00 · TEMPO LIVRE", listOf(Mission("rest", "Almoço, descanso, lazer e cochilo opcional", 5, "rest", "Opcional"))),
            MissionGroup("16:00 · ROUPA", listOf(Mission("fold", "Recolher e dobrar a roupa do varal", 10, "home", "Opcional"))),
            MissionGroup("~21:00 · TEMPO PESSOAL", listOf(Mission("call", "Namorada e lazer", 5, "relationship", "Opcional")))
        )
        return listOf(
            MissionGroup("ATÉ 08:30", listOf(Mission("light", "Acordar sem ultrapassar muito o horário", 5, "health", "Essencial"))),
            MissionGroup("MANHÃ LIVRE", listOf(Mission("rest", "Lazer livre, sem culpa", 5, "rest", "Opcional"))),
            MissionGroup("11:00 · ORGANIZAÇÃO", listOf(Mission("fold", "Guardar roupa limpa por 10 min", 10, "home", "Opcional"))),
            MissionGroup("15:00 · ESTUDO", listOf(Mission("study", "Estudar CNH ou japonês por 25 min (opcional)", 15, "study", "Opcional"))),
            MissionGroup("18:00 · PLANEJAMENTO", listOf(Mission("plan", "Planejar a semana por 10 min", 10, "home", "Opcional"))),
            MissionGroup("NOITE · DESCANSO", listOf(Mission("bath", "Banho e desaceleração às 23:00", 10, "health", "Essencial"))),
            MissionGroup("00:30 · SONO", listOf(Mission("bed", "Deitar no horário-alvo", 5, "health", "Essencial")))
        )
    }
}

private class LifeOsStore(context: Context) {
    private val prefs = context.getSharedPreferences("lifeos_native_v2_1", Context.MODE_PRIVATE)
    private var data: JSONObject = runCatching { JSONObject(prefs.getString("data", "{}") ?: "{}") }.getOrElse { JSONObject() }

    init {
        if (!data.has("days")) data.put("days", JSONObject())
        if (!data.has("xp")) data.put("xp", 0)
        if (!data.has("spent")) data.put("spent", 0)
        if (!data.has("achievements")) data.put("achievements", JSONObject())
        if (!data.has("rewards")) data.put("rewards", JSONArray().apply {
            put(rewardJson(Reward("reward-game", "🎮", "Uma hora extra de jogo", "Uma sessão de lazer sem culpa.", 50)))
            put(rewardJson(Reward("reward-film", "🍿", "Um filme ou episódio", "Aproveitar algo que você gosta.", 35)))
            put(rewardJson(Reward("reward-free", "🌙", "Uma noite livre", "Sem tarefas adicionais: descanso de verdade.", 60)))
        })
        if (!data.has("redemptions")) data.put("redemptions", JSONArray())
        if (!data.has("sessions")) data.put("sessions", JSONArray())
        if (!data.has("laundryWeek")) data.put("laundryWeek", 1)
        if (!data.has("fitnessWeek")) data.put("fitnessWeek", 1)
        if (!data.has("sleepWeek")) data.put("sleepWeek", 1)
        persist()
    }

    private fun persist() { prefs.edit().putString("data", data.toString()).apply() }
    private fun days(): JSONObject = data.optJSONObject("days") ?: JSONObject().also { data.put("days", it) }
    private fun dayObject(key: String, create: Boolean = false): JSONObject? {
        val ds = days()
        var day = ds.optJSONObject(key)
        if (day == null && create) { day = JSONObject().put("tasks", JSONObject()).put("survival", "off"); ds.put(key, day) }
        if (day != null && !day.has("tasks")) day.put("tasks", JSONObject())
        return day
    }
    private fun taskObject(key: String): JSONObject = dayObject(key, true)!!.optJSONObject("tasks") ?: JSONObject().also { dayObject(key, true)!!.put("tasks", it) }
    fun key(date: LocalDate) = date.toString()
    fun totalXP() = data.optInt("xp", 0)
    fun spentXP() = data.optInt("spent", 0)
    fun availableXP() = (totalXP() - spentXP()).coerceAtLeast(0)
    fun level() = totalXP() / 100 + 1
    fun xpProgress() = totalXP() % 100
    fun done(key: String, id: String) = taskObjectRead(key).has(id)
    private fun taskObjectRead(key: String) = dayObject(key)?.optJSONObject("tasks") ?: JSONObject()
    fun taskCount(key: String) = taskObjectRead(key).length()
    fun dayXp(key: String): Int { val tasks = taskObjectRead(key); var total = 0; val it = tasks.keys(); while (it.hasNext()) total += tasks.optJSONObject(it.next())?.optInt("xp", 0) ?: 0; return total }
    fun savedXp(key: String, id: String, fallback: Int): Int = taskObjectRead(key).optJSONObject(id)?.optInt("xp", fallback) ?: fallback
    fun entries(key: String): List<MissionEntry> {
        val tasks = taskObjectRead(key); val result = mutableListOf<MissionEntry>(); val it = tasks.keys()
        while (it.hasNext()) { val id = it.next(); val o = tasks.optJSONObject(id) ?: continue; result += MissionEntry(id, o.optString("label", id), o.optInt("xp", 0), o.optString("category", "general")) }
        return result.sortedBy { it.label }
    }
    fun toggle(key: String, mission: Mission, checked: Boolean): List<Achievement> {
        val tasks = taskObject(key); val exists = tasks.has(mission.id)
        if (checked && !exists) {
            tasks.put(mission.id, JSONObject().put("label", mission.label).put("xp", mission.xp).put("category", mission.category).put("at", System.currentTimeMillis()))
            data.put("xp", totalXP() + mission.xp)
        } else if (!checked && exists) {
            val previousXp = tasks.optJSONObject(mission.id)?.optInt("xp", mission.xp) ?: mission.xp
            tasks.remove(mission.id); data.put("xp", (totalXP() - previousXp).coerceAtLeast(0))
        }
        persist()
        return checkAchievements()
    }
    fun survival(key: String) = dayObject(key)?.optString("survival", "off") ?: "off"
    fun setSurvival(key: String, mode: String) { dayObject(key, true)!!.put("survival", mode); persist() }
    fun laundryWeek() = data.optInt("laundryWeek", 1).coerceIn(1, 4)
    fun fitnessWeek() = data.optInt("fitnessWeek", 1).coerceIn(1, 4)
    fun sleepWeek() = data.optInt("sleepWeek", 1).coerceIn(1, 5)
    fun setWeek(key: String, value: Int) { data.put(key, value); persist() }
    fun activeDays(): Int { val ds = days(); var c = 0; val it = ds.keys(); while (it.hasNext()) if (ds.optJSONObject(it.next())?.optJSONObject("tasks")?.length()?.let { n -> n > 0 } == true) c++; return c }
    fun allTaskCount(): Int { val ds = days(); var c = 0; val it = ds.keys(); while (it.hasNext()) c += ds.optJSONObject(it.next())?.optJSONObject("tasks")?.length() ?: 0; return c }
    fun hasCategory(category: String): Boolean { val ds = days(); val dayIt = ds.keys(); while (dayIt.hasNext()) { val tasks = ds.optJSONObject(dayIt.next())?.optJSONObject("tasks") ?: continue; val it = tasks.keys(); while (it.hasNext()) if (tasks.optJSONObject(it.next())?.optString("category") == category) return true }; return false }
    fun ritualDone(): Boolean { val ds = days(); val it = ds.keys(); while (it.hasNext()) { val tasks = ds.optJSONObject(it.next())?.optJSONObject("tasks") ?: continue; if (tasks.has("water") && tasks.has("food") && tasks.has("bath")) return true }; return false }
    fun survivalDone(): Boolean { val ds = days(); val it = ds.keys(); while (it.hasNext()) { val day = ds.optJSONObject(it.next()) ?: continue; val mode = day.optString("survival", "off"); val tasks = day.optJSONObject("tasks") ?: continue; val required = if (mode == "bad") Missions.survivalBad else if (mode == "worst") Missions.survivalWorst else emptyList(); if (required.isNotEmpty() && required.all { tasks.has(it.id) }) return true }; return false }
    fun checkAchievements(): List<Achievement> {
        val unlocked = data.optJSONObject("achievements") ?: JSONObject().also { data.put("achievements", it) }
        val conditions = mapOf(
            "first" to (allTaskCount() >= 1), "ten" to (allTaskCount() >= 10), "xp100" to (totalXP() >= 100),
            "ritual" to ritualDone(), "active3" to (activeDays() >= 3), "active7" to (activeDays() >= 7),
            "study" to hasCategory("study"), "fitness" to hasCategory("fitness"), "survival" to survivalDone()
        )
        val fresh = Achievements.filter { !unlocked.has(it.id) && conditions[it.id] == true }
        fresh.forEach { unlocked.put(it.id, System.currentTimeMillis()) }
        if (fresh.isNotEmpty()) persist()
        return fresh
    }
    fun isAchievementUnlocked(id: String) = data.optJSONObject("achievements")?.has(id) == true
    fun unlockedCount() = Achievements.count { isAchievementUnlocked(it.id) }
    fun rewards(): List<Reward> { val a = data.optJSONArray("rewards") ?: JSONArray(); return (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.toReward() } }
    fun addReward(reward: Reward) { data.optJSONArray("rewards")?.put(rewardJson(reward)); persist() }
    fun deleteReward(id: String) { val old = rewards().filterNot { it.id == id }; val arr = JSONArray(); old.forEach { arr.put(rewardJson(it)) }; data.put("rewards", arr); persist() }
    fun redeem(id: String): Boolean { val reward = rewards().firstOrNull { it.id == id } ?: return false; if (availableXP() < reward.cost) return false; data.put("spent", spentXP() + reward.cost); data.optJSONArray("redemptions")?.put(rewardJson(reward).put("date", System.currentTimeMillis())); persist(); return true }
    fun redemptionHistory(): List<Reward> { val a = data.optJSONArray("redemptions") ?: JSONArray(); return (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.toReward() } .reversed() }
    fun timerSnapshot(): TimerSnapshot? { val o = data.optJSONObject("timer") ?: return null; if (!o.optBoolean("running")) return null; return TimerSnapshot(o.optLong("endAt"), o.optInt("duration"), o.optString("label", "Foco"), true) }
    fun saveTimer(endAt: Long, duration: Int, label: String) { data.put("timer", JSONObject().put("endAt", endAt).put("duration", duration).put("label", label).put("running", true)); persist() }
    fun clearTimer() { data.put("timer", JSONObject().put("running", false)); persist() }
    fun recordSession(label: String, minutes: Int) { data.optJSONArray("sessions")?.put(JSONObject().put("label", label).put("minutes", minutes).put("date", System.currentTimeMillis())); clearTimer() }
    fun sessions(): List<TimerSession> { val a = data.optJSONArray("sessions") ?: JSONArray(); return (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { TimerSession(it.optString("label"), it.optInt("minutes"), it.optLong("date")) } }.reversed() }
    fun sessionMinutes() = sessions().sumOf { it.minutes }
    fun weekStats(today: LocalDate = LocalDate.now()): List<WeekStats> {
        val thisMonday = today.with(java.time.temporal.TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        return (7 downTo 0).map { offset -> val start = thisMonday.minusWeeks(offset.toLong()); val end = start.plusDays(6); var count = 0; var xp = 0; var daysCount = 0; var d = start; while (!d.isAfter(end)) { val c = taskCount(key(d)); if (c > 0) { count += c; xp += dayXp(key(d)); daysCount++ }; d = d.plusDays(1) }; WeekStats(start, end, count, xp, daysCount) }
    }
    private fun rewardJson(r: Reward) = JSONObject().put("id", r.id).put("icon", r.icon).put("name", r.name).put("description", r.description).put("cost", r.cost)
    private fun JSONObject.toReward() = Reward(optString("id"), optString("icon", "🎁"), optString("name"), optString("description"), optInt("cost"))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Android 15 enforces edge-to-edge for apps targeting API 35. Keep the
        // app content inside the safe window area so the status/navigation bars
        // never cover the header or bottom navigation on different devices.
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = android.graphics.Color.rgb(0, 42, 50)
        window.navigationBarColor = android.graphics.Color.rgb(0, 30, 36)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        setContent { LifeOsTheme { LifeOsApp(LifeOsStore(applicationContext)) } }
    }
}

@Composable
private fun LifeOsTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Red, secondary = Blue, tertiary = Gold, background = Bg, surface = Panel, onBackground = Ink, onSurface = Ink), content = content)
}

@Composable
private fun LifeOsApp(store: LifeOsStore) {
    var tab by remember { mutableStateOf("Início") }
    var revision by remember { mutableIntStateOf(0) }
    var newAchievement by remember { mutableStateOf<Achievement?>(null) }
    fun refresh(fresh: List<Achievement> = emptyList()) {
        revision++
        if (fresh.isNotEmpty()) newAchievement = fresh.first()
    }
    val tabs: List<Pair<String, ImageVector>> = listOf(
        "Início" to Icons.Outlined.Home,
        "Missões" to Icons.Outlined.EventNote,
        "Progresso" to Icons.Outlined.BarChart,
        "Skills" to Icons.Outlined.AccountTree,
        "Loja" to Icons.Outlined.CardGiftcard,
        "Foco" to Icons.Outlined.Timer
    )
    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(PanelAlt),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Outlined.Explore, contentDescription = "Life OS", tint = Red, modifier = Modifier.size(25.dp))
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("LIFE OS", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = Ink, letterSpacing = .8.sp)
                        Text("MODO CAMPANHA", fontSize = 8.sp, color = Muted, letterSpacing = 1.6.sp)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        Text("NÍVEL ${store.level()}", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("${store.totalXP()} XP", color = Muted, fontSize = 9.sp)
                    }
                    Surface(
                        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).clickable { tab = "Config" },
                        color = if (tab == "Config") CoralSoft else Panel,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Line)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Settings, contentDescription = "Configurações", tint = if (tab == "Config") Red else Muted, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
            Divider(color = Line.copy(alpha = .8f))
            val revisionToken = revision
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (revisionToken >= 0) {
                    when (tab) {
                        "Início" -> DashboardScreen(store, ::refresh, { tab = it })
                        "Missões" -> WeeklyScreen(store, ::refresh)
                        "Progresso" -> ProgressScreen(store)
                        "Skills" -> SkillsScreen(store, ::refresh)
                        "Loja" -> RewardsScreen(store, ::refresh)
                        "Foco" -> TimerScreen(store)
                        else -> SettingsScreen(store, ::refresh)
                    }
                }
            }
            Divider(color = Line)
            Row(
                modifier = Modifier.fillMaxWidth().background(Panel).padding(horizontal = 3.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tabs.forEach { (name, icon) ->
                    val selected = tab == name
                    Column(
                        modifier = Modifier.weight(1f).clip(RoundedCornerShape(11.dp))
                            .background(if (selected) CoralSoft else Color.Transparent)
                            .clickable { tab = name }.padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(icon, contentDescription = name, tint = if (selected) Red else Muted, modifier = Modifier.size(20.dp))
                        Text(name, fontSize = 8.sp, color = if (selected) Ink else Muted, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                    }
                }
            }
        }
        if (newAchievement != null) {
            val a = newAchievement!!
            AlertDialog(
                onDismissRequest = { newAchievement = null },
                containerColor = Panel,
                title = { Text("CONQUISTA DESBLOQUEADA", color = Red, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp) },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AnimatedVisibility(visible = true, enter = fadeIn(tween(220)) + scaleIn(initialScale = .62f, animationSpec = tween(360))) {
                            Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = Red, modifier = Modifier.size(42.dp))
                        }
                        Text(a.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text(a.description, color = Muted, textAlign = TextAlign.Center, fontSize = 12.sp)
                    }
                },
                confirmButton = { Button(onClick = { newAchievement = null }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Continuar") } }
            )
        }
    }
}

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 13.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
}

@Composable
private fun AppPanel(content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = androidx.compose.foundation.BorderStroke(1.dp, Line)) {
        Column(modifier = Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
private fun Kicker(text: String, color: Color = Blue) { Text(text.uppercase(), color = color, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp) }
@Composable
private fun PageTitle(title: String, subtitle: String) { Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink); Text(subtitle, fontSize = 11.sp, color = Muted) } }
@Composable
private fun Tag(text: String) { Surface(color = Color(0xFF17464D), shape = CircleShape) { Text(text, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), fontSize = 9.sp, color = Ink) } }

@Composable
private fun MissionRow(store: LifeOsStore, key: String, mission: Mission, onUpdate: (List<Achievement>) -> Unit, enabled: Boolean = true) {
    val checked = store.done(key, mission.id)
    Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(PanelAlt).padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, enabled = enabled, onCheckedChange = { onUpdate(store.toggle(key, mission, it)) }, colors = CheckboxDefaults.colors(checkedColor = Green, checkmarkColor = Bg, uncheckedColor = Muted, disabledCheckedColor = Green.copy(alpha = .5f), disabledUncheckedColor = Muted.copy(alpha = .35f)))
        Spacer(Modifier.width(5.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(mission.label, color = if (checked) Muted else Ink, fontSize = 12.sp, lineHeight = 16.sp)
            if (mission.note.isNotBlank()) Text(mission.note, color = Muted, fontSize = 8.sp)
        }
        if (mission.xp > 0) Text("+${store.savedXp(key, mission.id, mission.xp)} XP", color = if (checked) Green else Red, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        else Text("ETAPA", color = Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp)
    }
}

@Composable
private fun DashboardScreen(store: LifeOsStore, onUpdate: (List<Achievement>) -> Unit, onNavigate: (String) -> Unit) {
    val today = LocalDate.now(); val key = store.key(today); val xp = store.totalXP(); val progress = store.xpProgress() / 100f
    val isRitualDone = store.done(key, "water") && store.done(key, "food") && store.done(key, "bath")
    val survival = store.survival(key)
    ScreenColumn {
        AppPanel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) { Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = Red, modifier = Modifier.size(15.dp)); Kicker("Painel do jogador") }
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) { Text(when { java.time.LocalTime.now().hour < 12 -> "Bom dia, aventureiro."; java.time.LocalTime.now().hour < 18 -> "Sua campanha continua."; else -> "Bem-vindo de volta." }, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); Text("Consistência sem sacrificar descanso e saúde mental.", color = Muted, fontSize = 10.sp) }
                Tag("NÍVEL ${store.level()}")
            }
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) { Text("Experiência acumulada", color = Muted, fontSize = 10.sp); Text("${store.xpProgress()} / 100 XP", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            Box(modifier = Modifier.fillMaxWidth().height(9.dp).clip(CircleShape).background(Color(0xFF17464D))) { Box(modifier = Modifier.fillMaxWidth(progress).fillMaxHeight().background(Blue)) }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                StatBox("${store.taskCount(key)}", "MISSÕES HOJE", Modifier.weight(1f)); StatBox("${store.dayXp(key)}", "XP HOJE", Modifier.weight(1f)); StatBox("${store.activeDays()}", "DIAS ATIVOS", Modifier.weight(1f))
            }
        }
        AppPanel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) { Icon(Icons.Outlined.FavoriteBorder, contentDescription = null, tint = Red, modifier = Modifier.size(15.dp)); Kicker("Protocolo de emergência", Red) }
            Text("Dia difícil?", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("Reduza a campanha ao essencial. Sem culpa, sem XP negativo e sem compensar amanhã.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                if (survival == "bad") Button(onClick = { store.setSurvival(key, "bad"); onUpdate(emptyList()) }, colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), modifier = Modifier.weight(1f)) { Text("Dia Ruim", fontSize = 10.sp) }
                else OutlinedButton(onClick = { store.setSurvival(key, "bad"); onUpdate(emptyList()) }, border = androidx.compose.foundation.BorderStroke(1.dp, if (survival == "off") Line else Red.copy(alpha = .55f)), modifier = Modifier.weight(1f)) { Text("Dia Ruim", fontSize = 10.sp, color = if (survival == "off") Ink else Muted) }
                if (survival == "worst") Button(onClick = { store.setSurvival(key, "worst"); onUpdate(emptyList()) }, colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), modifier = Modifier.weight(1f)) { Text("Dia Péssimo", fontSize = 10.sp) }
                else OutlinedButton(onClick = { store.setSurvival(key, "worst"); onUpdate(emptyList()) }, border = androidx.compose.foundation.BorderStroke(1.dp, if (survival == "off") Line else Red.copy(alpha = .55f)), modifier = Modifier.weight(1f)) { Text("Dia Péssimo", fontSize = 10.sp, color = if (survival == "off") Ink else Muted) }
            }
            if (survival == "off") Text("Modo normal ativo · suas missões estão liberadas.", color = Muted, fontSize = 9.sp)
            else {
                Surface(color = CoralSoft, shape = RoundedCornerShape(10.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Red.copy(alpha = .38f))) {
                    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (survival == "bad") "DIA RUIM ATIVO" else "DIA PÉSSIMO ATIVO", color = Red, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .6.sp)
                        TextButton(onClick = { store.setSurvival(key, "off"); onUpdate(emptyList()) }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) { Text("Voltar ao normal", color = Ink, fontSize = 9.sp) }
                    }
                }
            }
            if (survival != "off") {
                val tasks = if (survival == "bad") Missions.survivalBad else Missions.survivalWorst
                Divider(color = Line); Text(if (survival == "bad") "MODO 1 — DIA RUIM" else "MODO 2 — DIA PÉSSIMO", color = Red, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = .6.sp)
                Text(if (survival == "bad") "Faça o que conseguir. Depois, encerre a campanha do dia." else "Se puder, avise alguém de confiança que o dia está pesado.", color = Muted, fontSize = 10.sp)
                tasks.forEach { MissionRow(store, key, it, onUpdate) }
                if (tasks.all { store.done(key, it.id) }) Text("Missão concluída. Pode descansar. Amanhã é um novo dia.", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (survival == "off") {
            AppPanel {
                Kicker("Evento principal", Red)
                Text("Chefe Final do Dia", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Ritual de chegada · aproximadamente 18:10–19:40", color = Muted, fontSize = 10.sp)
                PhaseTitle("FASE 1 — RETORNO À BASE", "~18:10")
                Missions.ritual1.forEach { MissionRow(store, key, it, onUpdate) }
                PhaseTitle("FASE 2 — REGENERAÇÃO", "~18:30")
                Missions.ritual2.forEach { MissionRow(store, key, it, onUpdate) }
                PhaseTitle("FASE 3 — RECOMPENSA", "18:50–19:40")
                Missions.ritual3.forEach { MissionRow(store, key, it, onUpdate, enabled = isRitualDone) }
                if (isRitualDone) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Icon(Icons.Outlined.CheckCircle, contentDescription = null, tint = Green, modifier = Modifier.size(17.dp))
                    Text("Ritual concluído. Água, comida e banho: PC liberado!", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            AppPanel {
                Kicker("Protocolo ativo", Red)
                Text("Rotina normal recolhida", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("As missões habituais ficam pausadas enquanto o modo de sobrevivência estiver ativo. Cuide apenas do essencial, sem tentar recuperar tarefas depois.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
        AppPanel {
            Kicker("Atributos", Red); Text("Áreas da campanha", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            val attrs = listOf("Saúde" to "Comer, banho e desacelerar", "Ambiente" to "Quarto e lavanderia", "Força" to "Calistenia gradual", "Conhecimento" to "CNH e japonês", "Recuperação" to "Lazer sem culpa", "Relacionamento" to "Tempo de qualidade")
            attrs.chunked(2).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { (a,b) -> Column(modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(PanelAlt).padding(10.dp)) { Text(a, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text(b, fontSize = 9.sp, color = Muted) } } } }
        }
        AppPanel {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column { Kicker("Regeneração", Red); Text("Sistema de sono", fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Meta para esta semana", color = Muted, fontSize = 9.sp) }; Text(SleepTimes[store.sleepWeek()-1], color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { SleepTimes.forEachIndexed { i, t -> Column(modifier = Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (i+1 == store.sleepWeek()) Color(0xFF3B2730) else PanelAlt).padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("${i+1}", color = Muted, fontSize = 8.sp); Text(t, color = if (i+1 == store.sleepWeek()) Gold else Ink, fontSize = 9.sp, fontWeight = FontWeight.Bold) } } }
            TextButton(onClick = { onNavigate("Config") }) { Text("Ajustar semana", color = Blue, fontSize = 10.sp) }
        }
    }
}

@Composable
private fun StatBox(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier.clip(RoundedCornerShape(11.dp)).background(PanelAlt).padding(9.dp)) { Text(value, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 7.sp) }
}
@Composable
private fun PhaseTitle(title: String, time: String) { Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(title, color = Gold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = .6.sp); Text(time, color = Muted, fontSize = 9.sp) } }

@Composable
private fun WeeklyScreen(store: LifeOsStore, onUpdate: (List<Achievement>) -> Unit) {
    var selected by remember { mutableStateOf(LocalDate.now()) }
    val monday = selected.with(java.time.temporal.TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    val todayKey = store.key(selected)
    ScreenColumn {
        PageTitle("Missões semanais", "Sugestões para guiar sua rotina. Opcionais não feitos não são falhas.")
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            OutlinedButton(onClick = { selected = selected.minusWeeks(1) }, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 7.dp)) { Text("‹", fontSize = 17.sp) }
            for (i in 0..6) {
                val d = monday.plusDays(i.toLong()); val active = d == selected
                Column(modifier = Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (active) Color(0xFF17464D) else Panel).clickable { selected = d }.padding(vertical = 9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(listOf("S","T","Q","Q","S","S","D")[i], color = if (active) Color(0xFFD5EEFF) else Muted, fontSize = 9.sp)
                    Text(d.dayOfMonth.toString(), color = if (active) Color.White else Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
            OutlinedButton(onClick = { selected = selected.plusWeeks(1) }, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 7.dp)) { Text("›", fontSize = 17.sp) }
        }
        AppPanel {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text(selected.format(DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.Bold, fontSize = 15.sp); Text("Missões sugeridas para o dia", color = Muted, fontSize = 9.sp) }
                Tag("${store.taskCount(todayKey)} concluídas")
            }
            val selectedSurvival = store.survival(todayKey)
            if (selectedSurvival == "bad" || selectedSurvival == "worst") {
                Text(
                    if (selectedSurvival == "bad") "DIA RUIM · MISSÕES ESSENCIAIS" else "DIA PÉSSIMO · PROTOCOLO MÍNIMO",
                    color = Red, fontWeight = FontWeight.Bold, fontSize = 10.sp
                )
                Text(
                    "A rotina completa fica recolhida neste dia. Não há tarefas para compensar depois.",
                    color = Muted, fontSize = 9.sp, lineHeight = 14.sp
                )
                val survivalTasks = if (selectedSurvival == "bad") Missions.survivalBad else Missions.survivalWorst
                survivalTasks.forEach { MissionRow(store, todayKey, it, onUpdate) }
            } else {
                Missions.schedule(selected).forEach { group ->
                    Text(group.title, color = Blue, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    group.tasks.forEach { MissionRow(store, todayKey, it, onUpdate) }
                }
            }
        }
        InfoNote("★ Missões essenciais ou presentes no Plano B. XP é recompensa simbólica: não há meta diária, punição ou XP negativo. Descansar também faz parte da campanha.")
    }
}

@Composable
private fun ProgressScreen(store: LifeOsStore) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selectedDay by remember { mutableStateOf(LocalDate.now()) }
    val weeks = store.weekStats()
    ScreenColumn {
        PageTitle("Histórico e conquistas", "Olhe para o que você construiu, não apenas para o que ficou pendente.")
        AppPanel {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column { Text("Histórico por semana", fontWeight = FontWeight.Bold, fontSize = 16.sp); Text("Últimas 8 semanas", color = Muted, fontSize = 9.sp) }; Tag("${weeks.sumOf { it.tasks }} missões") }
            val max = (weeks.maxOfOrNull { it.tasks } ?: 1).coerceAtLeast(1)
            weeks.forEachIndexed { index, w ->
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (index == 7) "Esta semana" else "Semana ${8-index}", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("${w.tasks} missões · ${w.xp} XP · ${w.days} dias", color = Muted, fontSize = 9.sp)
                    }
                    Box(modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(Color(0xFF17464D))) { Box(modifier = Modifier.fillMaxWidth(w.tasks.toFloat()/max).fillMaxHeight().background(Blue)) }
                }
            }
        }
        AppPanel {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("Calendário de missões", fontSize = 16.sp, fontWeight = FontWeight.Bold); Text("Toque em um dia para ver o que foi concluído.", color = Muted, fontSize = 9.sp) }
                Row(verticalAlignment = Alignment.CenterVertically) { TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹", fontSize = 20.sp) }; Text(month.format(DateTimeFormatter.ofPattern("MMM yyyy", Locale("pt", "BR"))), fontSize = 10.sp); TextButton(onClick = { month = month.plusMonths(1) }) { Text("›", fontSize = 20.sp) } }
            }
            Row { listOf("S","T","Q","Q","S","S","D").forEach { Text(it, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, color = Muted, fontSize = 9.sp) } }
            val first = month.atDay(1); val offset = first.dayOfWeek.value - 1; val cells = ((offset + month.lengthOfMonth() + 6) / 7) * 7
            for (row in 0 until cells/7) {
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    for (col in 0..6) {
                        val n = row*7+col-offset+1
                        if (n in 1..month.lengthOfMonth()) {
                            val d = month.atDay(n); val key = store.key(d); val count = store.taskCount(key); val active = d == selectedDay
                            Column(modifier = Modifier.weight(1f).height(43.dp).clip(RoundedCornerShape(8.dp)).background(when { active -> Color(0xFF1D6268); count > 0 -> Color(0xFF10414A); d == LocalDate.now() -> Color(0xFF292A2C); else -> PanelAlt }).clickable { selectedDay = d }.padding(vertical = 5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(n.toString(), fontSize = 10.sp, color = if (active) Color.White else Ink)
                                Box(modifier = Modifier.size(4.dp).clip(CircleShape).background(if (count > 0) Green else Color.Transparent))
                            }
                        } else Spacer(Modifier.weight(1f).height(43.dp))
                    }
                }
            }
            Divider(color = Line)
            Text(selectedDay.format(DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM", Locale("pt", "BR"))).replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            val entries = store.entries(store.key(selectedDay))
            if (entries.isEmpty()) Text("Nenhuma missão registrada neste dia. Tudo bem: a campanha continua.", color = Muted, fontSize = 10.sp) else entries.forEach { Text("✓ ${it.label}     +${it.xp} XP", fontSize = 10.sp, color = Color(0xFFD3DFEB)) }
        }
        AppPanel {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Galeria de conquistas", fontSize = 16.sp, fontWeight = FontWeight.Bold); Tag("${store.unlockedCount()}/${Achievements.size}") }
            Achievements.forEach { a ->
                val unlocked = store.isAchievementUnlocked(a.id)
                Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp)).background(if (unlocked) Color(0xFF3B2730) else PanelAlt).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    AchievementGlyph(a.id, unlocked); Spacer(Modifier.width(10.dp)); Column(modifier = Modifier.weight(1f)) { Text(a.title, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text(a.description, fontSize = 9.sp, color = Muted) }; Text(if (unlocked) "DESBLOQUEADA" else "BLOQUEADA", color = if (unlocked) Red else Muted, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}


@Composable
private fun AchievementGlyph(id: String, unlocked: Boolean) {
    val glyph = when (id) {
        "first", "ritual" -> Icons.Outlined.CheckCircle
        "ten", "study" -> Icons.Outlined.EventNote
        "xp100", "survival" -> Icons.Outlined.AutoAwesome
        "active3" -> Icons.Outlined.CalendarMonth
        "active7" -> Icons.Outlined.BarChart
        "fitness" -> Icons.Outlined.FitnessCenter
        else -> Icons.Outlined.AutoAwesome
    }
    Surface(color = if (unlocked) CoralSoft else PanelAlt, shape = RoundedCornerShape(12.dp)) {
        Icon(if (unlocked) glyph else Icons.Outlined.Lock, contentDescription = null, tint = if (unlocked) Red else Muted, modifier = Modifier.size(38.dp).padding(9.dp))
    }
}

@Composable
private fun SkillsScreen(store: LifeOsStore, onUpdate: (List<Achievement>) -> Unit) {
    val key = store.key(LocalDate.now())
    ScreenColumn {
        PageTitle("Árvores de habilidades", "Um passo de cada vez. Evolução por prática e autonomia.")
        AppPanel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) { Icon(Icons.Outlined.LocalLaundryService, contentDescription = null, tint = Red, modifier = Modifier.size(18.dp)); Kicker("Casa · Lavanderia", Red) }
            Text("Domínio da lavanderia", fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("10–15 minutos por dia. Quando o tempo acabar, pare.", color = Muted, fontSize = 10.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (1..4).forEach { i -> Box(modifier = Modifier.weight(1f).height(7.dp).clip(CircleShape).background(if (i <= store.laundryWeek()) Blue else Line)) } }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (1..4).forEach { i -> OutlinedButton(onClick = { store.setWeek("laundryWeek", i); onUpdate(emptyList()) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("N$i", fontSize = 10.sp, color = if (i == store.laundryWeek()) Blue else Muted) } } }
            Text(Missions.laundryTitles[store.laundryWeek()-1], fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Gold); Text(Missions.laundrySubs[store.laundryWeek()-1], fontSize = 9.sp, color = Muted)
            Missions.laundry[store.laundryWeek()-1].forEachIndexed { i, label -> MissionRow(store, key, Mission("laundry_${store.laundryWeek()}_$i", label, 5, "home", "10–15 min"), onUpdate) }
            Text(Missions.laundryRewards[store.laundryWeek()-1], color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            InfoNote("Regra permanente: roupa que sai do corpo vai direto para o cesto. A farda branca deve ser lavada separadamente, respeitando a etiqueta da peça.")
        }
        AppPanel {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) { Icon(Icons.Outlined.FitnessCenter, contentDescription = null, tint = Red, modifier = Modifier.size(18.dp)); Kicker("Corpo · Calistenia", Red) }
            Text("Força e controle", fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Terça, quinta e sábado · aproximadamente 20 minutos.", color = Muted, fontSize = 10.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (1..4).forEach { i -> Box(modifier = Modifier.weight(1f).height(7.dp).clip(CircleShape).background(if (i <= store.fitnessWeek()) Blue else Line)) } }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (1..4).forEach { i -> OutlinedButton(onClick = { store.setWeek("fitnessWeek", i); onUpdate(emptyList()) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("N$i", fontSize = 10.sp, color = if (i == store.fitnessWeek()) Blue else Muted) } } }
            Text(Missions.fitnessTitles[store.fitnessWeek()-1], fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Blue); Text(Missions.fitnessDescriptions[store.fitnessWeek()-1], fontSize = 10.sp, color = Muted)
            Missions.exercises.forEach { (label, exercise) -> Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, fontSize = 9.sp, color = Muted, modifier = Modifier.weight(.7f)); Text(exercise, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.3f), textAlign = TextAlign.End) }; Divider(color = Line.copy(alpha = .6f)) }
            InfoNote("Semanas 1–2: 2 rodadas. Semanas 3–4: 3 rodadas. Cada exercício: 30s de trabalho + 15s de descanso; 1 min entre rodadas. Priorize postura. Interrompa se sentir dor.")
        }
    }
}

@Composable
private fun RewardsScreen(store: LifeOsStore, onUpdate: (List<Achievement>) -> Unit) {
    var showDialog by remember { mutableStateOf(false) }
    var redeemTarget by remember { mutableStateOf<Reward?>(null) }
    ScreenColumn {
        PageTitle("Recompensas pessoais", "Transforme XP em pequenos momentos que você gosta.")
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            WalletCard("XP disponível", "${store.availableXP()}", Modifier.weight(1f)); WalletCard("XP conquistado", "${store.totalXP()}", Modifier.weight(1f)); WalletCard("Resgatado", "${store.spentXP()}", Modifier.weight(1f))
        }
        AppPanel {
            Text("Adicionar recompensa", fontSize = 16.sp, fontWeight = FontWeight.Bold); Text("Crie recompensas significativas, acessíveis e que não virem obrigação.", color = Muted, fontSize = 10.sp)
            Button(onClick = { showDialog = true }, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) { Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(17.dp)); Text("Criar recompensa") }
            }
        }
        AppPanel {
            Text("Sua loja", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            val rewards = store.rewards()
            if (rewards.isEmpty()) Text("Você ainda não criou recompensas.", color = Muted, fontSize = 10.sp)
            rewards.forEach { r ->
                Column(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(PanelAlt).padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text(r.icon, fontSize = 24.sp); Spacer(Modifier.width(9.dp)); Column(modifier = Modifier.weight(1f)) { Text(r.name, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text(r.description, fontSize = 9.sp, color = Muted) }; Text("${r.cost} XP", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Button(onClick = { redeemTarget = r }, enabled = store.availableXP() >= r.cost, modifier = Modifier.weight(1f)) { Text("Resgatar", fontSize = 10.sp) }
                        OutlinedButton(onClick = { store.deleteReward(r.id); onUpdate(emptyList()) }) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) { Icon(Icons.Outlined.DeleteOutline, contentDescription = null, modifier = Modifier.size(15.dp)); Text("Excluir", fontSize = 10.sp) }
                        }
                    }
                }
            }
        }
        AppPanel {
            Text("Histórico de resgates", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            val list = store.redemptionHistory()
            if (list.isEmpty()) Text("Nenhuma recompensa resgatada ainda.", color = Muted, fontSize = 10.sp)
            list.take(10).forEach { Text("${it.icon} ${it.name} · ${it.cost} XP", color = Muted, fontSize = 10.sp); Divider(color = Line) }
        }
        InfoNote("O XP gasto em recompensas não reduz seu nível. Marque apenas o que realizou; a loja é um incentivo, não uma dívida.")
    }
    if (showDialog) AddRewardDialog(onDismiss = { showDialog = false }, onAdd = { icon, name, description, cost -> store.addReward(Reward("r-${System.currentTimeMillis()}", icon, name, description, cost)); showDialog = false; onUpdate(emptyList()) })
    if (redeemTarget != null) {
        val r = redeemTarget!!
        AlertDialog(onDismissRequest = { redeemTarget = null }, containerColor = Panel, title = { Text("Resgatar recompensa?", fontWeight = FontWeight.Bold) }, text = { Text("${r.icon} ${r.name}\n\nCusto: ${r.cost} XP. Isso não altera seu nível. Aproveite sem culpa.", color = Muted, fontSize = 12.sp) }, confirmButton = { Button(onClick = { val ok = store.redeem(r.id); redeemTarget = null; onUpdate(emptyList()) }) { Text("Confirmar") } }, dismissButton = { TextButton(onClick = { redeemTarget = null }) { Text("Cancelar") } })
    }
}

@Composable
private fun WalletCard(title: String, value: String, modifier: Modifier = Modifier) { Column(modifier = modifier.clip(RoundedCornerShape(12.dp)).background(Panel).padding(10.dp)) { Text(title, fontSize = 8.sp, color = Muted); Text("$value XP", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Blue) } }

@Composable
private fun AddRewardDialog(onDismiss: () -> Unit, onAdd: (String, String, String, Int) -> Unit) {
    var name by remember { mutableStateOf("") }; var icon by remember { mutableStateOf("🎮") }; var description by remember { mutableStateOf("") }; var cost by remember { mutableStateOf("50") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text("Nova recompensa") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = name, onValueChange = { name = it.take(50) }, label = { Text("Nome") }, singleLine = true)
            OutlinedTextField(value = icon, onValueChange = { icon = it.take(4) }, label = { Text("Ícone") }, singleLine = true)
            OutlinedTextField(value = cost, onValueChange = { cost = it.filter(Char::isDigit).take(5) }, label = { Text("Custo em XP") }, singleLine = true)
            OutlinedTextField(value = description, onValueChange = { description = it.take(90) }, label = { Text("Descrição (opcional)") }, singleLine = true)
        }
    }, confirmButton = { Button(onClick = { val c = cost.toIntOrNull()?.coerceIn(1, 10000) ?: 50; if (name.isNotBlank()) onAdd(icon.ifBlank { "🎁" }, name.trim(), description.trim(), c) }, enabled = name.isNotBlank()) { Text("Criar") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } })
}

@Composable
private fun TimerScreen(store: LifeOsStore) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val saved = remember { store.timerSnapshot() }
    var label by remember { mutableStateOf(saved?.label ?: "Estudo") }
    var duration by remember { mutableIntStateOf(saved?.durationSeconds ?: 20*60) }
    var endAt by remember { mutableLongStateOf(saved?.endAt ?: 0L) }
    var running by remember { mutableStateOf(saved?.running ?: false) }
    var remaining by remember { mutableIntStateOf(if (saved != null) ((saved.endAt-System.currentTimeMillis())/1000).toInt().coerceAtLeast(0) else 20*60) }
    var custom by remember { mutableStateOf("15") }
    LaunchedEffect(running, endAt) {
        if (running) {
            while (true) {
                val left = ((endAt - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
                remaining = left
                if (left <= 0) {
                    running = false
                    store.recordSession(label, (duration/60).coerceAtLeast(1))
                    Toast.makeText(context, "Bloco de $label concluído!", Toast.LENGTH_LONG).show()
                    break
                }
                delay(250)
            }
        }
    }
    fun choose(minutes: Int, name: String) { running = false; label = name; duration = minutes*60; remaining = duration; endAt = 0; store.clearTimer() }
    ScreenColumn {
        PageTitle("Temporizador", "Blocos curtos para estudar ou cuidar da casa. Encerrar no tempo combinado também é vitória.")
        AppPanel {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(20 to "Estudo", 10 to "Casa", 5 to "Pausa").forEach { (minutes, name) ->
                    OutlinedButton(onClick = { choose(minutes, name) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 3.dp, vertical = 8.dp)) { Text("$name\n$minutes min", fontSize = 9.sp, textAlign = TextAlign.Center) }
                }
            }
            Box(modifier = Modifier.fillMaxWidth().padding(vertical = 17.dp), contentAlignment = Alignment.Center) {
                Box(modifier = Modifier.size(220.dp).clip(CircleShape).background(Color(0xFF17464D)).padding(11.dp).clip(CircleShape).background(PanelAlt), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val mm = remaining/60; val ss = remaining%60
                        Text("${mm.toString().padStart(2,'0')}:${ss.toString().padStart(2,'0')}", fontSize = 42.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                        Text(label.uppercase(), color = Muted, fontSize = 9.sp, letterSpacing = 1.2.sp)
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = {
                    if (running) { remaining = ((endAt-System.currentTimeMillis())/1000).toInt().coerceAtLeast(0); running = false; store.clearTimer() }
                    else { if (remaining <= 0) remaining = duration; endAt = System.currentTimeMillis()+remaining*1000L; running = true; store.saveTimer(endAt, duration, label) }
                }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(if (running) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(17.dp))
                        Text(if (running) "Pausar" else "Iniciar")
                    }
                }
                OutlinedButton(onClick = { running = false; endAt = 0; remaining = duration; store.clearTimer() }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Outlined.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("Reiniciar")
                    }
                }
            }
            Text(if (running) "Bloco em andamento. Foque apenas nesta etapa." else if (remaining == 0) "Sessão concluída. Você fez o tempo que combinou." else "Escolha um bloco e comece no seu ritmo.", color = Muted, textAlign = TextAlign.Center, fontSize = 10.sp, modifier = Modifier.fillMaxWidth())
            Divider(color = Line)
            Text("Personalizar duração", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = custom, onValueChange = { custom = it.filter(Char::isDigit).take(3) }, modifier = Modifier.weight(1f), label = { Text("Minutos") }, singleLine = true)
                OutlinedButton(onClick = { choose((custom.toIntOrNull() ?: 15).coerceIn(1,180), "Personalizado") }) { Text("Aplicar") }
            }
        }
        AppPanel {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Sessões recentes", fontSize = 15.sp, fontWeight = FontWeight.Bold); Tag("${store.sessionMinutes()} min") }
            val sessions = store.sessions()
            if (sessions.isEmpty()) Text("Suas sessões concluídas aparecerão aqui.", color = Muted, fontSize = 10.sp)
            sessions.take(10).forEach { s -> Text("${s.label} · ${s.minutes} min · ${java.text.SimpleDateFormat("dd/MM", Locale("pt", "BR")).format(java.util.Date(s.date))}", fontSize = 10.sp, color = Muted); Divider(color = Line) }
        }
    }
}

@Composable
private fun SettingsScreen(store: LifeOsStore, onUpdate: (List<Achievement>) -> Unit) {
    ScreenColumn {
        PageTitle("Configurações", "O progresso do app nativo fica salvo no próprio dispositivo.")
        AppPanel {
            Text("Progressão", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Semana da meta de sono", color = Muted, fontSize = 10.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { SleepTimes.forEachIndexed { i, t -> OutlinedButton(onClick = { store.setWeek("sleepWeek", i+1); onUpdate(emptyList()) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text(t, color = if (i+1 == store.sleepWeek()) Gold else Muted, fontSize = 9.sp) } } }
            Text("Meta atual: ${SleepTimes[store.sleepWeek()-1]}", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        AppPanel {
            Text("Dados e privacidade", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Este aplicativo Android é nativo: sua interface é feita com Jetpack Compose, não é uma página dentro de um navegador. O progresso é armazenado em SharedPreferences no aparelho; o app não solicita permissão de internet.", color = Muted, fontSize = 10.sp, lineHeight = 16.sp)
            Text("Para trocar de celular, esta versão ainda não tem sincronização em nuvem. Use o backup do PWA ou faça backup do dispositivo Android.", color = Muted, fontSize = 10.sp, lineHeight = 16.sp)
        }
        AppPanel {
            Text("Leis da campanha", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            InfoNote("1. Não existe Game Over por perder um dia.\n2. Não tente compensar amanhã o que não fez.\n3. A versão reduzida também conta.\n4. Descansar de verdade faz parte da campanha.\n5. O jogo foi feito para se adaptar a você, não o contrário.")
        }
        Text("Life OS · Android nativo 2.1", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun InfoNote(text: String) {
    Surface(color = Color(0xFF0B3941), shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Line)) {
        Text(text, modifier = Modifier.padding(11.dp), color = Color(0xFFB8C9DD), fontSize = 9.sp, lineHeight = 14.sp)
    }
}
